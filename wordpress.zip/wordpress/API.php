<?php
    $connect = mysqli_connect("localhost","root","","wordpress");
    $sql = "SELECT ID, post_title FROM `wp_posts` WHERE post_type = 'product' AND post_status = 'publish'";

    $result = mysqli_query($connect,$sql);

    $json_array = array();

    while($row = mysqli_fetch_assoc($result))
    {
        $json_array[] = $row;
    }
/*
    echo'<pre>';
    print_r($json_array);
    echo'</pre>';
*/
    echo json_encode($json_array);
    
    ?>